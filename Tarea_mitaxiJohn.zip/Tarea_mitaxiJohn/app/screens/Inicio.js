import react from "react";
import {view, text} from "react-native";

export default function Inicio(){
    return(
        <view>
            <text>Mi Casita John</text>
        </view>
    )
}