import react from "react";
import {view, text} from 'react-native';

export default function Mispedidos() {
    return(
        <view>
            <text>Estos son mis pedidos</text>
        </view>
    )
}