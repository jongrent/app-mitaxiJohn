import react from "react";
import{view, text} from 'react-native';

export default function Servi(){
    return(
        <view>
            <text>Estos son los servicios</text>
        </view>
    )
}