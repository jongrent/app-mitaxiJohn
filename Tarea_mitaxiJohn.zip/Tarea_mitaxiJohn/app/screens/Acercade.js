import react from "react";
import {view, text} from 'react-native';

export default function Acercade(){
    return(
        <view>
            <text>Estos son mis pedidos</text>
        </view>
    )
}